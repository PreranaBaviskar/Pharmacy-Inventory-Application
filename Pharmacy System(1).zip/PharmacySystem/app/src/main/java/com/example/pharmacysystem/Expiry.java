package com.example.pharmacysystem;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Expiry extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_expiry);
    }
}
